<?php
/**
 * VNS revision 2026-05-23: only display jersey numbers in admin order items when parent product show_numbers is enabled.
 */

namespace Averun\SizeChart\Plugin\Adminhtml;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Sales\Block\Adminhtml\Items\Column\DefaultColumn;

class AppendJerseyNumbersToOrderOptions
{
    private ProductRepositoryInterface $productRepository;

    public function __construct(ProductRepositoryInterface $productRepository)
    {
        $this->productRepository = $productRepository;
    }

    public function afterGetOrderOptions(DefaultColumn $subject, array $result): array
    {
        $item = $subject->getItem();

        if (!$item) {
            return $result;
        }

        $productOptions = $item->getProductOptions();

        if (!is_array($productOptions)) {
            return $result;
        }

        if (!$this->isShowNumbersEnabled($item, $productOptions)) {
            return $result;
        }

        if ($this->hasJerseyNumbersOption($result)) {
            return $result;
        }

        $jerseyNumbers = $this->extractJerseyNumbers($productOptions);

        if ($jerseyNumbers === '') {
            return $result;
        }

        $result[] = [
            'label' => 'Jersey Numbers',
            'value' => $jerseyNumbers,
        ];

        return $result;
    }

    private function isShowNumbersEnabled($item, array $productOptions): bool
    {
        $productId = 0;
        $buyRequest = $productOptions['info_buyRequest'] ?? [];

        if (is_array($buyRequest) && !empty($buyRequest['product'])) {
            $productId = (int)$buyRequest['product'];
        }

        if (!$productId && $item->getProductId()) {
            $productId = (int)$item->getProductId();
        }

        if (!$productId) {
            return false;
        }

        try {
            $product = $this->productRepository->getById($productId, false, null, true);
        } catch (NoSuchEntityException $e) {
            return false;
        } catch (\Exception $e) {
            return false;
        }

        $showNumbersValue = $product->getData('show_numbers');

        return in_array((string)$showNumbersValue, ['1', 'true', 'yes', 'on'], true) || $showNumbersValue === true;
    }

    private function extractJerseyNumbers(array $productOptions): string
    {
        $buyRequest = $productOptions['info_buyRequest'] ?? [];

        if (!is_array($buyRequest)) {
            return '';
        }

        if (isset($buyRequest['jersey_numbers'])) {
            return $this->cleanNumberList((string)$buyRequest['jersey_numbers']);
        }

        if (isset($buyRequest['ave_jersey_numbers']) && is_array($buyRequest['ave_jersey_numbers'])) {
            $rows = [];

            foreach ($buyRequest['ave_jersey_numbers'] as $size => $numbers) {
                $size = trim(strip_tags((string)$size));
                $numbers = $this->cleanNumberList((string)$numbers);

                if ($size !== '' && $numbers !== '') {
                    $rows[] = $size . ': ' . $numbers;
                }
            }

            return implode('; ', $rows);
        }

        return '';
    }

    private function cleanNumberList(string $numbers): string
    {
        $numbers = preg_replace('/[^0-9,\s]/', '', $numbers);
        $parts = preg_split('/,/', (string)$numbers);
        $cleanParts = [];

        foreach ($parts as $part) {
            $part = preg_replace('/\s+/', '', (string)$part);

            if ($part !== '') {
                $cleanParts[] = $part;
            }
        }

        return implode(', ', $cleanParts);
    }

    private function hasJerseyNumbersOption(array $options): bool
    {
        foreach ($options as $option) {
            if (!is_array($option) || !isset($option['label'])) {
                continue;
            }

            $label = strtolower(trim((string)$option['label']));

            if ($label === 'jersey numbers' || strpos($label, 'jersey numbers') === 0) {
                return true;
            }
        }

        return false;
    }
}
