/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            reviewRatingBehave: 'Magento_Review/js/reviewRating'
        }
    }
};